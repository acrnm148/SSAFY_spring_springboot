package com.mycom.myapp.user.service;

import java.util.List;

import com.mycom.myapp.user.dto.CodeDto;

public interface CodeService {
	List<CodeDto> getCodeList();
}
