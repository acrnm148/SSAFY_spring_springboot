package com.mycom.myapp.user.dto;

public class UserResultDto {
	private int result;

	public int getResult() {
		return result;
	}

	public void setResult(int result) {
		this.result = result;
	}
	
}
