package com.mycom.myapp.user.service;

import com.mycom.myapp.user.dto.UserDto;

public interface LoginService {
	UserDto login(UserDto dto);
}
