package com.mycom.myapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WhereIsMyHome5KsnMshApplication {

	public static void main(String[] args) {
		SpringApplication.run(WhereIsMyHome5KsnMshApplication.class, args);
	}

}
